export const environment = {
  firebase: {
    apiKey: "AIzaSyAE9dBj95zdm6yZ9SXFOIn_XholH3E3_8Y",
  authDomain: "project-angular-tdc.firebaseapp.com",
  projectId: "project-angular-tdc",
  storageBucket: "project-angular-tdc.appspot.com",
  messagingSenderId: "833679017069",
  appId: "1:833679017069:web:ad6f087ca42cbe4945ab64",
  measurementId: "G-K3JVT87VK3"
      }
};
