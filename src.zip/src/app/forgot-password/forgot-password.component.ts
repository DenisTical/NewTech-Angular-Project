import { Component, OnInit } from '@angular/core';
import { AuthServiceService } from '../auth-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  email:any;
  
  constructor(private authService:AuthServiceService, private router:Router){}

  ngOnInit(): void {
    
  }

  async resetPass(){
    if(confirm('Are you sure you want to delete this user?')){
      (await this.authService.deleteUser(this.email)).subscribe(() => {
        alert('User deleted!');
      })
      this.router.navigate(['login']);
    }
  }
}
