import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthServiceService } from '../auth-service.service';

@Component({
  selector: 'app-profile-edit',
  templateUrl: './profile-edit.component.html',
  styleUrls: ['./profile-edit.component.css']
})
export class ProfileEditComponent implements OnInit{
  editProfileForm:FormGroup;

  constructor(private route:ActivatedRoute, private authService:AuthServiceService, private router:Router){}

  async ngOnInit(): Promise<void> {
    this.editProfileForm = new FormGroup({
      fname: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z]{2,}$')]),
      lname: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z]{2,}$')]),
      email: new FormControl('', [Validators.required, this.emailFormatValidator]),
      password: new FormControl('', [Validators.required, this.passwordFormatValidator]),
      confirmPassword: new FormControl('', [Validators.required, this.confirmPasswordValidator.bind(this)]),
      age: new FormControl('', [Validators.required, this.ageRangeValidator]),
      isAdmin: new FormControl(''),
      shifts: new FormControl(''),
    });

    (await this.authService.getCurrentUser()).subscribe((data) => {
      this.editProfileForm.patchValue({
        fname: data['fname'],
        lname: data['lname'],
        email: data['email'],
        password: data['password'],
        confirmPassword: data['confirmPassword'],
        age: data['age'],
        isAdmin: data['isAdmin'],
        shifts: data['shifts'],
      });
    });
  }

  async editProfile(){
    const updatedUser = {
      fname: this.editProfileForm.value.fname,
      lname: this.editProfileForm.value.lname,
      email: this.editProfileForm.value.email,
      password: this.editProfileForm.value.password,
      confirmPassword: this.editProfileForm.value.confirmPassword,
      age: this.editProfileForm.value.age,
    };
    (await this.authService.updateProfile(updatedUser)).subscribe(() => {
      console.log('profile updated');
      this.router.navigate(['/main-page']);
    })
  }

  return(){
    this.router.navigate(['/main-page']);
  }

  emailFormatValidator(control: FormControl){
    const emailPattern = /^\s*\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  
    if (!emailPattern.test(control.value)) {
      return { invalidEmail: true };
    }
  
    return null;
  }

  passwordFormatValidator(control:FormControl){
    const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (!passwordPattern.test(control.value)) {
      return { invalidPassword: true };
    }
    return null;
  }

  confirmPasswordValidator(control:FormControl){
    const password = this.editProfileForm?.get('password').value;
    const confirmPassword = control.value;
    if(!password){
      return null;
    }
    if(password === confirmPassword){
      return null;
    }else{
      return { passwordMisMatch:true };
    }
  }

  ageRangeValidator(control:FormControl){
    const age = control.value;
    if(age === null || age === undefined){
      return null;
    }
    if(age < 18 || age > 65){
      return { ageRange:true };
    }
    return null;
  }
}
