import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { MainPageComponent } from './main-page/main-page.component';
import { AddShiftComponent } from './add-shift/add-shift.component';
import { EditShiftComponent } from './edit-shift/edit-shift.component';
import { ProfileEditComponent } from './profile-edit/profile-edit.component';
import { MyShiftsComponent } from './my-shifts/my-shifts.component';
import { AllWorkersComponent } from './admin-main/all-workers/all-workers.component';
import { AllShiftsComponent } from './admin-main/all-shifts/all-shifts.component';
import { EditUserComponent } from './admin-main/edit-user/edit-user.component';
import { EditAllShiftsComponent } from './admin-main/edit-all-shifts/edit-all-shifts.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';

const routes: Routes = [
  {path: 'welcome', component: WelcomeComponent},
  {path: 'register', component: RegisterComponent},
  {path: 'login', component: LoginComponent},
  {path: 'main-page', component: MainPageComponent},
  {path: 'my-shift', component: MyShiftsComponent},
  {path: 'add-shift', component: AddShiftComponent},
  {path: 'edit-shift/:id', component: EditShiftComponent},
  {path: 'edit-profile', component: ProfileEditComponent},
  {path: 'admin/all-users', component: AllWorkersComponent},
  {path: 'admin/all-shifts', component: AllShiftsComponent},
  {path: 'admin/edit-profile/:id', component: EditUserComponent},
  {path: 'admin/edit-shifts/:id', component: EditAllShiftsComponent},
  {path: 'forgot-password', component: ForgotPasswordComponent},


  {path: '', redirectTo: 'welcome', pathMatch: 'full'},
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes),
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
