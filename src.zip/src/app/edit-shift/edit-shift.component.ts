import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthServiceService } from '../auth-service.service';

@Component({
  selector: 'app-edit-shift',
  templateUrl: './edit-shift.component.html',
  styleUrls: ['./edit-shift.component.css']
})
export class EditShiftComponent implements OnInit {
  editShiftForm:FormGroup;
  shiftId:any;

  constructor(private route:ActivatedRoute, private authService:AuthServiceService, private router: Router){}

  async ngOnInit(): Promise<void> {
    this.editShiftForm = new FormGroup({
      eid: new FormControl(''),
      edate: new FormControl(''),
      ebegTime: new FormControl(''),
      eendTime: new FormControl(''),
      eprice: new FormControl(''),
      eplace: new FormControl(''),
      eslug: new FormControl(''),
      ecomments: new FormControl(''),
    });

    this.shiftId = this.route.snapshot.paramMap.get('id');
    (await this.authService.getShiftById(this.shiftId)).subscribe((data) => {
      this.editShiftForm.patchValue({
        eid: data['id'],
        edate: data['date'],
        ebegTime: data['begTime'],
        eendTime: data['endTime'],
        eprice: data['price'],
        eplace: data['place'],
        eslug: data['slug'],
        ecomments: data['comments'],
      });
    });
  }

  async editShift(){
    const updatedShift = {
      id: this.editShiftForm.value.eid,
      date: this.editShiftForm.value.edate,
      begTime: this.editShiftForm.value.ebegTime,
      endTime: this.editShiftForm.value.eendTime,
      place: this.editShiftForm.value.eplace,
      price: this.editShiftForm.value.eprice,
      slug: this.editShiftForm.value.eslug,
      comments: this.editShiftForm.value.ecomments,
    };
    
    (await this.authService.updateShift(this.shiftId, updatedShift)).subscribe(() => {
      console.log('updated');
      this.router.navigate(['my-shift']);
    });
  }

  return(){
    this.router.navigate(['/my-shift']);
  }
}
