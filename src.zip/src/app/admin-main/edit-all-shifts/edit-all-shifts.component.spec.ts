import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditAllShiftsComponent } from './edit-all-shifts.component';

describe('EditAllShiftsComponent', () => {
  let component: EditAllShiftsComponent;
  let fixture: ComponentFixture<EditAllShiftsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EditAllShiftsComponent]
    });
    fixture = TestBed.createComponent(EditAllShiftsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
