import { Component } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthServiceService } from 'src/app/auth-service.service';

@Component({
  selector: 'app-edit-all-shifts',
  templateUrl: './edit-all-shifts.component.html',
  styleUrls: ['./edit-all-shifts.component.css']
})
export class EditAllShiftsComponent {
  editUserShiftForm:FormGroup;
  shiftsId:any;

  constructor(private route:ActivatedRoute, private authService:AuthServiceService, private router: Router){}

  async ngOnInit(): Promise<void> {
    this.editUserShiftForm = new FormGroup({
      eid: new FormControl(''),
      edate: new FormControl(''),
      ebegTime: new FormControl(''),
      eendTime: new FormControl(''),
      eprice: new FormControl(''),
      eplace: new FormControl(''),
      eslug: new FormControl(''),
      ecomments: new FormControl(''),
    });

    this.shiftsId = this.route.snapshot.paramMap.get('id');
    (await this.authService.getShiftByIdAdmin(this.shiftsId)).subscribe((data) => {
      console.log(data)
      this.editUserShiftForm.patchValue({
        eid: data['id'],
        edate: data['date'],
        ebegTime: data['begTime'],
        eendTime: data['endTime'],
        eprice: data['price'],
        eplace: data['place'],
        eslug: data['slug'],
        ecomments: data['comments'],
      });
    });
  }

  async editUserShift(){
    const updatedUserShift = {
      id: this.editUserShiftForm.value.eid,
      date: this.editUserShiftForm.value.edate,
      begTime: this.editUserShiftForm.value.ebegTime,
      endTime: this.editUserShiftForm.value.eendTime,
      place: this.editUserShiftForm.value.eplace,
      price: this.editUserShiftForm.value.eprice,
      slug: this.editUserShiftForm.value.eslug,
      comments: this.editUserShiftForm.value.ecomments,
    };
    
    (await this.authService.updateShiftAdmin(this.shiftsId, updatedUserShift)).subscribe(() => {
      console.log('updated');
      this.router.navigate(['/admin/all-shifts']);
    });
  }

  return(){
    this.router.navigate(['/admin/all-shifts']);
  }
}
