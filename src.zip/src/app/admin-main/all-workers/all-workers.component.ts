import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthServiceService } from 'src/app/auth-service.service';

@Component({
  selector: 'app-all-workers',
  templateUrl: './all-workers.component.html',
  styleUrls: ['./all-workers.component.css']
})
export class AllWorkersComponent implements OnInit {
  users:any;

  constructor(private authService:AuthServiceService, private route:Router){}

  async ngOnInit(): Promise<void> {
    (await this.authService.getAllUsers()).subscribe((data) => {
      this.users = data;
    });
  }

  async deleteUser(uidUser){
    (await this.authService.deleteAllUser(uidUser)).subscribe((data) => {
      this.users = data;
    });
  }

  return(){
    this.route.navigate(['/main-page']);
  }
}
