import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthServiceService } from 'src/app/auth-service.service';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit{
  editUserProfileForm:FormGroup;
  userUid:any;

  constructor(private route:ActivatedRoute, private authService:AuthServiceService, private router:Router){}

  async ngOnInit(): Promise<void> {
    this.editUserProfileForm = new FormGroup({
      fname: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z]{2,}$')]),
      lname: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z]{2,}$')]),
      email: new FormControl('', [Validators.required, this.emailFormatValidator]),
      password: new FormControl('', [Validators.required, this.passwordFormatValidator]),
      confirmPassword: new FormControl('', [Validators.required, this.confirmPasswordValidator.bind(this)]),
      age: new FormControl('', [Validators.required, this.ageRangeValidator]),
      isAdmin: new FormControl(''),
      shifts: new FormControl(''),
    });

    this.userUid = this.route.snapshot.paramMap.get('id');
    (await this.authService.getUserByUidAdmin(this.userUid)).subscribe((data) => {
      this.editUserProfileForm.patchValue({
        fname: data['fname'],
        lname: data['lname'],
        email: data['email'],
        password: data['password'],
        confirmPassword: data['confirmPassword'],
        age: data['age'],
        isAdmin: data['isAdmin'],
        shifts: data['shifts'],
      });
    });
  }

  async editUserProfile(){
    const newData = {
      fname: this.editUserProfileForm.value.fname,
      lname: this.editUserProfileForm.value.lname,
      email: this.editUserProfileForm.value.email,
      password: this.editUserProfileForm.value.password,
      confirmPassword: this.editUserProfileForm.value.confirmPassword,
      age: this.editUserProfileForm.value.age,
    };
    (await this.authService.updateUserProfileAdmin(this.userUid, newData)).subscribe(() => {
      console.log('profile updated');
      this.router.navigate(['/admin/all-users']);
    })
  }

  return(){
    this.router.navigate(['/admin/all-users']);
  }

  emailFormatValidator(control: FormControl){
    const emailPattern = /^\s*\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  
    if (!emailPattern.test(control.value)) {
      return { invalidEmail: true };
    }
  
    return null;
  }

  passwordFormatValidator(control:FormControl){
    const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (!passwordPattern.test(control.value)) {
      return { invalidPassword: true };
    }
    return null;
  }

  confirmPasswordValidator(control:FormControl){
    const password = this.editUserProfileForm?.get('password').value;
    const confirmPassword = control.value;
    if(!password){
      return null;
    }
    if(password === confirmPassword){
      return null;
    }else{
      return { passwordMisMatch:true };
    }
  }

  ageRangeValidator(control:FormControl){
    const age = control.value;
    if(age === null || age === undefined){
      return null;
    }
    if(age < 18 || age > 65){
      return { ageRange:true };
    }
    return null;
  }
}
