import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthServiceService } from 'src/app/auth-service.service';

@Component({
  selector: 'app-all-shifts',
  templateUrl: './all-shifts.component.html',
  styleUrls: ['./all-shifts.component.css']
})
export class AllShiftsComponent implements OnInit{
  startDate:any;
  endDate:any;
  shifts:any;
  shiftName:any;

  constructor(private authService:AuthServiceService, private route:Router){}
  
  async ngOnInit(): Promise<void> {
    (await this.authService.getAllUsers()).subscribe((data) => {
      this.shifts = data;
    });
  }

  salaryPerShift(date:string, begTime:string, endTime:string, price:string){
    let timeStart = new Date(`${date} ${begTime}`);
    let timeEnd = new Date(`${date} ${endTime}`);
    let timeShift = (timeEnd.getHours() + (timeEnd.getMinutes()/60) - (timeStart.getHours() + timeStart.getMinutes()/60));
    if(timeShift > 0){
      let salaryPerShift = +(timeShift * (+price)).toFixed(2);
      return salaryPerShift;
    } else{
      let salaryPerShift = +(-timeShift * (+price)).toFixed(2);
      return salaryPerShift;
    }
  }

  async deleteShiftUser(uidUser:any, shiftId:any){
    (await this.authService.deleteShiftUserAdmin(uidUser, shiftId)).subscribe((data) => {
      this.shifts = data;
    })
  }

  async searchByDate(){
    (await this.authService.getShiftByDateAdmin(this.startDate, this.endDate)).subscribe((data) => {
      this.shifts = data;
      console.log(this.shifts)
    });
  }

  // async searchShiftsByName(){
  //   if(this.shiftName){
  //     (await this.authService.shiftsByName(this.shiftName)).subscribe((data) => {
  //       this.shifts = data;
  //     });
  //   }else{
  //     window.location.reload();
  //   }
  // }

  return(){
    this.route.navigate(['/main-page']);
  }
}
