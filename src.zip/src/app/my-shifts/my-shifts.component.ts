import { Component, OnInit } from '@angular/core';
import { AuthServiceService } from '../auth-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-my-shifts',
  templateUrl: './my-shifts.component.html',
  styleUrls: ['./my-shifts.component.css']
})
export class MyShiftsComponent implements OnInit {
  shifts:any;
  startDate:any;
  endDate:any;
  shiftName:any;

  constructor(private authService:AuthServiceService, private route:Router){}

  async ngOnInit(): Promise<void> {
    (await this.authService.getShiftsForRegularUser('', '')).subscribe((data) => {
      this.shifts = data;
    });
  }

  salaryPerShift(date:string, begTime:string, endTime:string, price:string){
    let timeStart = new Date(`${date} ${begTime}`);
    let timeEnd = new Date(`${date} ${endTime}`);
    let timeShift = (timeEnd.getHours() + (timeEnd.getMinutes()/60) - (timeStart.getHours() + timeStart.getMinutes()/60));
    if(timeShift > 0){
      let salaryPerShift = +(timeShift * (+price)).toFixed(2);
      return salaryPerShift;
    }else{
      let salaryPerShift = +(-timeShift * (+price)).toFixed(2);
      return salaryPerShift;
    }
  }

  mostProfit(){
    const mostProfitShift = this.shifts.map((shift:any) => {
       return this.salaryPerShift(shift.date, shift.begTime, shift.endTime, shift.price);
      })
      return Math.max(...mostProfitShift);
  }

  async delete(shiftId:any){
    try{
      (await this.authService.deleteShift(shiftId)).subscribe((data) => {
        this.shifts = data;
      });
    }catch(err){
      console.log('Error in deleting shift');
    }
  }

  async searchByDate(){
    (await this.authService.getShiftsForRegularUser(this.startDate, this.endDate)).subscribe((data) => {
      this.shifts = data;
    });
  }

  async searchShiftsByName(){
    if(this.shiftName){
      (await this.authService.shiftsByName(this.shiftName)).subscribe((data) => {
        this.shifts = data;
      });
    } else {
      window.location.reload();
    }
  }
  
  return(){
    this.route.navigate(['/main-page']);
  }
}
