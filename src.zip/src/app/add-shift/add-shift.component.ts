import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthServiceService } from '../auth-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-shift',
  templateUrl: './add-shift.component.html',
  styleUrls: ['./add-shift.component.css']
})
export class AddShiftComponent implements OnInit {
  addShiftForm:FormGroup;

  constructor(private authService:AuthServiceService, private route:Router){}

  ngOnInit(): void {
    this.addShiftForm = new FormGroup({
      id: new FormControl(this.generateRandomId()),
      date: new FormControl('', [Validators.required]),
      begTime: new FormControl('', [Validators.required]),
      endTime: new FormControl('', [Validators.required]),
      price: new FormControl('', [Validators.required]),
      place: new FormControl('', [Validators.required]),
      slug: new FormControl('', [Validators.required]),
      comments: new FormControl(''),
    })
  }

  async saveShift(){
    const shift = {
      id: this.addShiftForm.value.id,
      date: this.addShiftForm.value.date,
      begTime: this.addShiftForm.value.begTime,
      endTime: this.addShiftForm.value.endTime,
      price: this.addShiftForm.value.price,
      place: this.addShiftForm.value.place,
      slug: this.addShiftForm.value.slug,
      comments: this.addShiftForm.value.comments,
    };

    (await this.authService.addNewShift(shift)).subscribe(() => {
      console.log('shift added');
      this.route.navigate(['/main-page']);
    });
  }

  generateRandomId(){
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    let result = '';
    for(let i = 0; i < 8; i++){
      const randomIndex = Math.floor((Math.random() * charactersLength));
      result += characters.charAt(randomIndex);
    }
    return result;
  }

  return(){
    this.route.navigate(['/main-page']);
  }
}
