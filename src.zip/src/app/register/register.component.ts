import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, Form } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthServiceService } from '../auth-service.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForms:FormGroup;

  constructor(private authService: AuthServiceService, private route:Router){}

  ngOnInit(): void {
    this.registerForms = new FormGroup({
      fname: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z]{2,}$')]),
      lname: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z]{2,}$')]),
      email: new FormControl('', [Validators.required, this.emailFormatValidator]),
      password: new FormControl('', [Validators.required, this.passwordFormatValidator]),
      confirmPassword: new FormControl('', [Validators.required, this.confirmPasswordValidator.bind(this)]),
      age: new FormControl(null, [Validators.required, this.ageRangeValidator]),
      isAdmin: new FormControl(false),
      shifts: new FormControl([]),
    })
  }

  async register(){
    try{
      const { email, password, confirmPassword, fname, lname, age, isAdmin, shifts} = this.registerForms.value
      this.authService.signup(email, password, confirmPassword, fname, lname, age, isAdmin, shifts).then(() => {
        this.route.navigate(['/login']);
      })
    }catch(err){
      console.error("Error adding user:", err);
    }
  }

  get fname(){
    return this.registerForms.get('fname');
  }

  get lname(){
    return this.registerForms.get('lname');
  }

  get email(){
    return this.registerForms.get('email');
  }

  get password(){
    return this.registerForms.get('password');
  }

  get confirmPassword(){
    return this.registerForms.get('confirmPassword');
  }

  get age(){
    return this.registerForms.get('age');
  }

  emailFormatValidator(control: FormControl){
    const emailPattern = /^\s*\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  
    if (!emailPattern.test(control.value)) {
      return { invalidEmail: true };
    }
  
    return null;
  }

  passwordFormatValidator(control:FormControl){
    const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (!passwordPattern.test(control.value)) {
      return { invalidPassword: true };
    }
    return null;
  }

  confirmPasswordValidator(control:FormControl){
    const password = this.registerForms?.get('password').value;
    const confirmPassword = control.value;
    if(!password){
      return null;
    }
    if(password === confirmPassword){
      return null;
    }else{
      return { passwordMisMatch:true };
    }
  }

  ageRangeValidator(control:FormControl){
    const age = control.value;
    if(age === null || age === undefined){
      return null;
    }
    if(age < 18 || age > 65){
      return { ageRange:true };
    }
    return null;
  }
}
