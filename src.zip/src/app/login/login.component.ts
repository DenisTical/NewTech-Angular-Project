import { Component, OnInit } from '@angular/core';
import { AuthServiceService } from '../auth-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{
  email:string = '';
  password:string = '';

  constructor(private authService:AuthServiceService, private route:Router){}

  ngOnInit(): void {

  }

  async loginUser() {
    try {
      await this.authService.login(this.email, this.password);
      console.log('user logged in');
      this.route.navigate(['/main-page']);
    } catch (error) {
      console.log("Error logging user", error);
      alert('Invalid Credentials!');
    }
  }
}