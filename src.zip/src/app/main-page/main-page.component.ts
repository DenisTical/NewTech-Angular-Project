import { Component, OnInit } from '@angular/core';
import { AuthServiceService } from '../auth-service.service';
import { Router } from '@angular/router';
import { getAuth, signOut } from '@angular/fire/auth';

@Component({
  selector: 'app-main-page',
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.css']
})
export class MainPageComponent implements OnInit {
  currentUser:any | null;

  constructor(private authService:AuthServiceService, private route:Router){}

  async ngOnInit(): Promise<void> {
    (await this.authService.getCurrentUser()).subscribe((user) => {
      this.currentUser = user;
    });
  }

  logout(){
    if(this.currentUser){
      const auth = getAuth();
      signOut(auth);
    }
  }
}
