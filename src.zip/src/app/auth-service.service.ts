import { Injectable } from '@angular/core';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, getAuth, updateEmail, updatePassword } from '@angular/fire/auth';
import { Firestore, arrayUnion, collection, doc, getDoc, getDocs, setDoc, updateDoc, query, deleteDoc, where } from '@angular/fire/firestore';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {

  constructor(private firestore:Firestore) { }


  //Register


  async signup(email:string, password:string, confirmPassword:string, fname:string, lname:string, age:number, isAdmin:boolean, shifts:any){
    try{
      const auth = getAuth();
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const userUid = userCredential.user.uid;

      const userDoc = doc(this.firestore, 'users', userUid);
      await setDoc(userDoc, {
        fname,
        lname,
        email,
        password,
        confirmPassword,
        age,
        isAdmin,
        shifts,
      });
    }catch(err){
      console.log('error in creating new account');
    }
  }


  //Login


  async login(email:any, password:any) {
    try{
      const auth = getAuth();
      await signInWithEmailAndPassword(auth, email, password);
    }catch(error){
      throw error;
    }
  }

  async deleteUser(email:string){
    const auth = getAuth();
    return new Observable((observer) => {
      auth.onAuthStateChanged(async (user) => {
        try{
          if(!user){
            const usersCollection = collection(this.firestore, 'users');
            const userQuery = query(usersCollection);
            const userDocs = getDocs(userQuery);
            const usersInfo = (await userDocs).docs.map((document) => ({
                ...document.data(),
                uid: document.id,
              }));

              const userToDelete = usersInfo.find(el => el['email'] === email);
              if(userToDelete){
                const userUidToDelete = userToDelete['uid'];
                const userRef = doc(this.firestore, 'users', userUidToDelete);
                const deletedUser = deleteDoc(userRef);

                observer.next(deletedUser);
              }else{
                alert('This email does not exist in database!');
              }
          }else{
           console.log('One user is authenticated');
          }
        }catch(err){
          console.error('error deleting user', err);
          throw err;
        }
      })
    })
  }


  //Main-Page

  
  async getCurrentUser(){
    const auth =  getAuth();
    return new Observable((observer) => {
      auth.onAuthStateChanged(async (user) => {
        if(user){
          let userRef = doc(this.firestore, 'users', user.uid);
          let userDoc = await getDoc(userRef);
          if(userDoc.exists()){
            const userData = {
              ...user,
              ...userDoc.data()
            }
            observer.next(userData);
          }
        }else{
          observer.next(null);
        }
      });
    });
  }

  isAuthenticated(){
    const auth = getAuth();
    return new Observable((observer) => {
      auth.onAuthStateChanged((user) => {
        observer.next(!!user);
      });
    });
  }

  async addNewShift(shift:any){
    const auth = getAuth();
    return new Observable((observer) => {
      auth.onAuthStateChanged(async (user) => {
        try{
          if(!user){
            console.log('No user is authenticated!');
          }else{
            const userId = user.uid;
            const userDocRef = doc(this.firestore, 'users', userId);
            await updateDoc(userDocRef, {
              shifts: arrayUnion(shift),
            });
          }
          observer.next();
        }catch(err){
          console.log('err', err);
        }
      });
    });
  }

  async getShiftsForRegularUser(sDate:any, eDate:any){
    const auth = getAuth();
    return new Observable((observer) => {
      auth.onAuthStateChanged(async (user) => {
        try{
          if(user){
            const userId = user.uid;
            const userDocRef = doc(this.firestore, 'users', userId);
            const userDoc = getDoc(userDocRef);
            const userData = (await userDoc).data();
            if(sDate && eDate){
              const startDate = new Date(sDate);
              const endDate = new Date(eDate);
              const filteredShifts = userData['shifts'].filter((shift:any) => {
                const shiftDate = new Date(shift.date);
                return shiftDate >= startDate && shiftDate <= endDate;
              });
              observer.next(filteredShifts);
            }else{
              observer.next(userData['shifts']);
            }
          }else{
            console.log('No user');
          }
        }catch(err){
          console.log('err', err);
        }
      });
    });
  }

  async shiftsByName(name:string){
    const auth = getAuth();
    return new Observable((observer) => {
      auth.onAuthStateChanged(async (user) => {
        try{
          if(user){
            const userId = user.uid;
            const useDocRef = doc(this.firestore, 'users', userId);
            const userDoc = getDoc(useDocRef);
            const userData = (await userDoc).data();
            if(name){
              const filteredShifts = userData['shifts'].filter((shift:any) => {
                return shift.place.includes(name);
              });
              observer.next(filteredShifts);
            }
            }
        }catch(err){
          console.error("error", err)
        }
      });
    });
  }

  async getShiftById(id:any){
    const auth = getAuth();
    return new Observable((observer) => {
      auth.onAuthStateChanged(async (user) => {
        try{
          if(user){
            const userId = user.uid;
            const userDocRef = doc(this.firestore, 'users', userId);
            const userDoc = getDoc(userDocRef);
            const userData = (await userDoc).data();
            const userShifts = userData['shifts'];
            const userFilteredShift = userShifts.find((el:any) => el.id === id);
            observer.next(userFilteredShift);
          }else{
            console.log('No user');
          }
        }catch(err){
          console.log('Error getting shift by id', err);
        }
      });
    });
  }

  async deleteShift(id:any){
    const auth = getAuth();
    return new Observable((observer) => {
      auth.onAuthStateChanged(async (user) => {
        try{
          if(user){
            const userId = user.uid;
            const userDocRef = doc(this.firestore, 'users', userId);
            const userDoc = getDoc(userDocRef);
            const userData = (await userDoc).data();

            if(userData['shifts']){
              const shiftIndex = userData['shifts'].findIndex((shift:any) => shift.id === id);
              userData['shifts'].splice(shiftIndex, 1);
            }

            await updateDoc(userDocRef, {
              shifts: userData['shifts'],
            });

            observer.next(userData['shifts']);
          }else{
            console.log('No user');
          }
        }catch(err){
          console.log('err', err);
        }
      });
    });
  }

  async updateShift(id:any, updatedData:any){
    const auth = getAuth();
    return new Observable((observer) => {
      auth.onAuthStateChanged(async (user) => {
        try{
          if(user){
            const userId = user.uid;
            const userDocRef = doc(this.firestore, 'users', userId);
            const userDoc = getDoc(userDocRef);
            const userData = (await userDoc).data();
            const userShifts = userData['shifts'];
            const userFilteredShift = userShifts.find((el:any) => el.id === id);
            
            if(userFilteredShift){
              Object.assign(userFilteredShift, updatedData);
              await updateDoc(userDocRef, {shifts: userShifts});
              observer.next(userShifts);
            }else{
              console.log('Shift not found');
            }
          }else{
            console.log('No user');
          }
        }catch(err){
          console.log('Error getting shift by id', err);
        }
      });
    });
  }

  async updateProfile(updatedData:any){
    const auth = getAuth();
    return new Observable((observer) => {
      auth.onAuthStateChanged(async (user) => {
        try{
          if(user){
            const userId = user.uid;

            if(updatedData.email){
              await updateEmail(user, updatedData.email);
            }
            if(updatedData.password){
              await updatePassword(user, updatedData.password);
            }

            const userDocRef = doc(this.firestore, 'users', userId);
            const userDoc = getDoc(userDocRef);
            const userData = (await userDoc).data();
            const updatedUserData = {...userData, ...updatedData};

            await setDoc(userDocRef, updatedUserData);
            observer.next(updatedUserData);
          }else{
            observer.next(null);
          }
        }catch(err){
          console.log('Error updating profile', err);
        }
      });
    });
  }


  //ADMIN


  async getAllUsers(){
    const auth = getAuth();
    return new Observable((observer) => {
      auth.onAuthStateChanged(async (user) => {
        try{
          if(!user){
            console.log('No user is authenticated');
          }else{
            const userId = user.uid;
            const userDocRef = doc(this.firestore, 'users', userId);
            const userDoc = getDoc(userDocRef);
            const userData = (await userDoc).data();

            if(userData['isAdmin']){
              const userCollection = collection(this.firestore, 'users');
              const usersQuery = query(userCollection);
              const userDocs = getDocs(usersQuery);
              const usersInfo = (await userDocs).docs.filter((document) => document.id !== userId).map((document) => ({
                ...document.data(),
                uid: document.id,
              }));
              observer.next(usersInfo);
            }else{
              throw console.error('You are not an admin');
            }
          }
        }catch(err){
          console.log('err', err);
        }
      });
    });
  }

  async deleteAllUser(userUidToDelete:any){
    const auth = getAuth();
    return new Observable((observer) => {
      auth.onAuthStateChanged(async (user) => {
        try{
          if(!user){
            console.log('No User is authenticated');
          }else{
            const userDocRef = doc(this.firestore, 'users', user.uid);
            const userDoc = getDoc(userDocRef);
            const userData = (await userDoc).data();

            if(!userData['isAdmin']){
              console.log('You are not an Admin');
            }else{
              const userDocToDelete = doc(this.firestore, 'users', userUidToDelete);
              deleteDoc(userDocToDelete);
            }

            const usersCollection = collection(this.firestore, 'users');
            const allUsers = getDocs(usersCollection);
            const remainingUsers = (await allUsers).docs.filter((el) => el.id !== user.uid).map((el) => ({
              uid: el.id,
              ...el.data(),
            }));

            observer.next(remainingUsers);
          }
        }catch(err){
          console.log('err', err);
        }
      });
    });
  }

  async getUserByUidAdmin(uidUser:any){
    const auth = getAuth();
    return new Observable((observer) => {
      auth.onAuthStateChanged(async (user) => {
        try{
          if(!user){
            console.log('No User is authenticated');
          }else{
            const userDocRef = doc(this.firestore, 'users', user.uid);
            const userDoc = getDoc(userDocRef);
            const userData = (await userDoc).data();

            if(!userData['isAdmin']){
              console.log('You are not an Admin');
            }
            
            const userDocRecord = doc(this.firestore, 'users', uidUser);
            const userDocument = getDoc(userDocRecord);
            const userDataRecord = (await userDocument).data();
            observer.next(userDataRecord);
          }
        }catch(err){
          console.log('err', err);
        }
      });
    });
  }

  async updateUserProfileAdmin(uidUser:any, updatedData:any){
    const auth = getAuth();
    return new Observable((observer) => {
      auth.onAuthStateChanged(async (user) => {
        try{
          if(!user){
            console.log('No User is authenticated');
          }else{
            const userDocRef = doc(this.firestore, 'users', user.uid);
            const userDoc = getDoc(userDocRef);
            const userData = (await userDoc).data();

            if(!userData['isAdmin']){
              console.log('You are not an Admin');
            }
            
            const userDocRecord = doc(this.firestore, 'users', uidUser);
            const updatedUserData = {...updatedData};

            updateDoc(userDocRecord, updatedUserData);
            observer.next(updatedUserData);
          }
        }catch(err){
          console.log('err', err);
        }
      });
    });
  }

  async deleteShiftUserAdmin(userUid:any, shiftId:any){
    const auth = getAuth();
    return new Observable((observer) => {
      auth.onAuthStateChanged(async (user) => {
        try{
          if(!user){
            console.log('No user is authenticated');
          }

          const userDocRef = doc(this.firestore, 'users', user.uid);
          const userDoc = getDoc(userDocRef);
          const userData = (await userDoc).data();

          if(!userData['isAdmin']){
            console.log('You are not an Admin');
          }

          const userRecordRef = doc(this.firestore, 'users', userUid);
          const userRecord = getDoc(userRecordRef);
          const userDataRecord = (await userRecord).data();
          if(userDataRecord['shifts']){
            const shiftIndex = userDataRecord['shifts'].findIndex((element:any) => element.id === shiftId);
            userDataRecord['shifts'].splice(shiftIndex, 1);
          }

          updateDoc(userRecordRef, {
            shifts: userDataRecord['shifts'],
          })

          const usersCollection = collection(this.firestore, 'users');
          const usersQuery = query(usersCollection);
          const userDocs = getDocs(usersQuery);
          const usersInfo = (await userDocs).docs.filter((document) => document.id !== user.uid).map((document) => ({
            ...document.data(),
            uid: document.id,
          }))

          observer.next(usersInfo);
        }catch(err){
          console.log('err', err);
        }
      });
    });
  }

  async getShiftByIdAdmin(shiftUid:any){
    const auth = getAuth();
    return new Observable((observer) => {
      auth.onAuthStateChanged(async (user) => {
        try{
          if(!user){
            console.log('No user is authenticated');
          }

          const userDocRef = doc(this.firestore, 'users', user.uid);
          const userDoc = getDoc(userDocRef);
          const userData = (await userDoc).data();

          if(!userData['isAdmin']){
            console.log('You are not an Admin');
          }

          const usersCollection = collection(this.firestore, 'users');
          const usersQuery = query(usersCollection);
          const userDocs = getDocs(usersQuery);
          const usersInfo = (await userDocs).docs.filter((document) => document.id !== user.uid).map((document) => ({
            ...document.data(),
            uid: document.id,
          }));

          for(const regularUser of usersInfo){
            if(regularUser['shifts']){
              const shiftToFind = regularUser['shifts'].find((shift:any) => shift.id === shiftUid);
              observer.next(shiftToFind);
            }
          }
        }catch(err){
          console.log('err', err);
        }
      });
    });
  }

  async updateShiftAdmin(shiftUid:any, updatedData:any){
    const auth = getAuth();
    return new Observable((observer) => {
      auth.onAuthStateChanged(async (user) => {
        try{
          if(!user){
            console.log('No user is authenticated');
          }

          const userDocRef = doc(this.firestore, 'users', user.uid);
          const userDoc = getDoc(userDocRef);
          const userData = (await userDoc).data();

          if(!userData['isAdmin']){
            console.log('You are not an Admin');
          }

          const usersCollection = collection(this.firestore, 'users');
          const usersQuery = query(usersCollection);
          const userDocs = getDocs(usersQuery);
          const usersInfo = (await userDocs).docs.filter((document) => document.id !== user.uid).map((document) => ({
            ...document.data(),
            uid: document.id,
          }));

          for(const regularUser of usersInfo){
            if(regularUser['shifts']){
              const shiftToFindIndex = regularUser['shifts'].findIndex((shift:any) => shift.id === shiftUid);
              regularUser['shifts'][shiftToFindIndex] = {
                ...regularUser['shifts'][shiftToFindIndex],
                ...updatedData,
              }

              const userDocRef = doc(this.firestore, 'users', regularUser.uid);
              updateDoc(userDocRef, {
                shifts: regularUser['shifts'],
              })

              observer.next(usersInfo);
            }
          }
        }catch(err){
          console.log('err', err);
        }
      });
    });
  }

  async getShiftByDateAdmin(sDate:any, eDate:any){
    const auth = getAuth();
    return new Observable((observer) => {
      auth.onAuthStateChanged(async (user) => {
        try{
          if(!user){
            console.log('No user is authenticated');
          }

          const userDocRef = doc(this.firestore, 'users', user.uid);
          const userDoc = getDoc(userDocRef);
          const userData = (await userDoc).data();

          if(!userData['isAdmin']){
            console.log('You are not an Admin');
          }

          const usersCollection = collection(this.firestore, 'users');
          const usersQuery = query(usersCollection);
          const userDocs = getDocs(usersQuery);
          const usersInfo = (await userDocs).docs.filter((document) => document.id !== user.uid).map((document) => (
            
            {
            ...document.data(),
            uid: document.id,
          }
          )
          );

          const userFilter = usersInfo.map((document) => {
            const startDate = new Date(sDate);
            const endDate = new Date(eDate);
            const filteredShifts = document['shifts'].filter((shift:any) => {
              const shiftDate = new Date(shift.date);
              return shiftDate >= startDate && shiftDate <= endDate;
            });
            return filteredShifts
          })
          console.log(userFilter)
          observer.next(userFilter)

          // if(sDate && eDate){
          //   const startDate = new Date(sDate);
          //   const endDate = new Date(eDate);
          //   const filteredShifts = usersInfo['shifts'].filter((shift:any) => {
          //     const shiftDate = new Date(shift.date);
          //     return shiftDate >= startDate && shiftDate <= endDate;
          //   });
          //   observer.next(filteredShifts);
          // }else{
          //   observer.next('no user');
          // }
        }catch(err){
          console.log('err', err);
        }
      });
    });
  }
}
